SELECT mgm.Id,
       mgm.ModelGroupId,
       mgm.ModelId,
       mgm.IsNew
FROM [dbo].ModelGroupModel mgm